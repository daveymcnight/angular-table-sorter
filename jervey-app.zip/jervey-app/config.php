<?php




class config{

    public static $host = "127.0.0.1";
    public static $username = "jervey";
    public static $password = "jervey";
    public static $database = "jervey";

}




?>