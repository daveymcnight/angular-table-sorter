<?php
?>

<!DOCTYPE html>
<html>
<head lang="en">
    <link rel="stylesheet" type="text/css" href="../../../assets/css/styles.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="http://ajax.googleapis.com/ajax/libs/angularjs/1.2.26/angular.min.js"></script>
    <script src="../../../assets/js/scripts.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
    <meta charset="UTF-8">
    <header id="header">
    <div class="logoheader">
        <img id="logo" src="http://myjervey.com/images/jeg-logo.png">
        <div class="nav">
        </div>
    </div><!-- end logoheader -->
    <div id="header-image">
    </div>
    </header>


<!--

 Add Header from Joomla

 -->

