<?php

phpinfo();

?><pre><?php var_dump(ini_get_all()); ?></pre>