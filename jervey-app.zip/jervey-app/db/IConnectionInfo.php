<?php
/**
 * Created by PhpStorm.
 * User: McDavis
 * Date: 4/3/15
 * Time: 1:47 PM
 */

interface IConnectionInfo {

//    const HOST = "127.0.0.1";
//    const USERNAME = "jervey";
//    const PASSWORD = "jervey";
//    const DBNAME = "jervey";



    const HOST = "64.89.81.173";
    const USERNAME = "myjervey";
    const PASSWORD = "Pin_Hole_July_2013";
    const DBNAME = "jeg_wh";
    const PORT = "3306";



    public function openConnection();
    public function closeConnection();

}